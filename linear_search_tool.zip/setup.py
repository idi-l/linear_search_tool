from setuptools import setup, find_packages

setup(
    name="linear_search_tool",
    version="0.1",
    packages=find_packages(),
    description="Outil simple de recherche linéaire",
)
