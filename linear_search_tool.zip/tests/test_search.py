import unittest
from linear_search_tool.search import linear_search

class TestLinearSearch(unittest.TestCase):
    def test_found(self):
        self.assertEqual(linear_search([1, 2, 3], 2), 1)

    def test_not_found(self):
        self.assertEqual(linear_search([1, 2, 3], 4), -1)

if __name__ == "__main__":
    unittest.main()
