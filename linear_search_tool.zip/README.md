# Linear Search Tool

Un petit projet Python qui implémente une recherche linéaire.

## Utilisation

```bash
python main.py
```

## Tests

```bash
python -m unittest
```
